module.exports = {
    jwtSecret: 'ketxam',
    saltRounds: 10
};